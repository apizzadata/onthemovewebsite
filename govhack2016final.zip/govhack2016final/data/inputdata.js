Main Language       
Not stated  303450  44.10%
English 116781  16.97%
Mandarin    42794   6.22%
Arabic  19180   2.79%
Hindi   13810   2.01%
Chinese, nec    10704   1.56%
Punjabi 9614    1.40%
Urdu    9051    1.32%
Vietnamese  8930    1.30%
Nepali  8410    1.22%
Malayalam   6868    1.00%
Dari    5955    0.87%
Bengali 5481    0.80%
Tamil   5286    0.77%
Korean  5126    0.74%
Telugu  5086    0.74%
Filipino    4823    0.70%
Cantonese   4817    0.70%
Spanish 4696    0.68%
Chinese, nfd    4442    0.65%
Sinhalese   4309    0.63%
Gujarati    4207    0.61%
(blank) 4193    0.61%
Thai    3944    0.57%
Hazaragi    3454    0.50%
French  3256    0.47%
Assyrian    3192    0.46%
Farsi (Persian) 3137    0.46%
Russian 3073    0.45%
Indonesian  3064    0.45%
Portuguese  2503    0.36%
Persian 2298    0.33%
Farsi (Afghan)  2134    0.31%
Italian 2016    0.29%
German  1970    0.29%
Marathi 1965    0.29%
Swahili 1812    0.26%
Japanese    1698    0.25%
Afrikaans   1689    0.25%
Somali  1665    0.24%
Burmese / Myanmar   1640    0.24%
Kannada 1478    0.21%
Khmer   1364    0.20%
Karen Sgaw 1271    0.18%
Chin Haka   1240    0.18%
Pashto  1200    0.17%
Turkish 1161    0.17%
Chin    1108    0.16%
Karen   1108    0.16%
Persian (excluding Dari)    991 0.14%
Tigrinya    975 0.14%
Polish  885 0.13%
Malay   878 0.13%
Burmese and Related Languages, nfd  843 0.12%
Amharic 841 0.12%
Tagalog 841 0.12%
Indian  817 0.12%
Dutch   740 0.11%
Oromo   679 0.10%
Chaldean Neo-Aramaic    673 0.10%
Chaldaean   639 0.09%
Serbian 633 0.09%
Greek   580 0.08%
Shona   571 0.08%
Tibetan 570 0.08%
Hungarian   532 0.08%
Dinka   477 0.07%
Romanian    473 0.07%
Macedonian  436 0.06%
OTHER LANGUAGES 367 0.05%
Sri Lankan  360 0.05%
Hebrew  359 0.05%
Chin Teddim 331 0.05%
Ukrainian   315 0.05%
Czech   306 0.04%
Armenian    300 0.04%
Swedish 286 0.04%
Kurdish 276 0.04%
Sindhi  272 0.04%
Slovak  268 0.04%
African Languages, nec  263 0.04%
Albanian    249 0.04%
Kirundi / Nyarwandwa / Rundi    244 0.04%
Chin Falam  240 0.03%
Cebuano 226 0.03%
Oriya   215 0.03%
Pakistani   209 0.03%
Bisaya/Visaya   200 0.03%
Croatian    189 0.03%
Kinyarwanda / Rwanda    183 0.03%
Konkani 181 0.03%
Rohinga 167 0.02%
Tigre   162 0.02%
Estonian    161 0.02%
Yoruba  159 0.02%
Bosnian 141 0.02%
Mauritian Creole    141 0.02%
Bulgarian   137 0.02%
Chin Mara   136 0.02%
Finnish 135 0.02%
Kachin  127 0.02%
Fijian  123 0.02%
Danish  115 0.02%
Non-verbal so dscrbd    114 0.02%
Igbo    108 0.02%
Dzonkha 107 0.02%
Chin Zome   103 0.01%
Lao 99  0.01%
African Languages, nfd  97  0.01%
Chin Zotong 96  0.01%
Karen Pwo   95  0.01%
Bemba   94  0.01%
Zophei  90  0.01%
Lithuanian  87  0.01%
Lingala 81  0.01%
Slovene 80  0.01%
Norwegian   79  0.01%
Tulu    76  0.01%
Akan    75  0.01%
Papua New Guinea Papuan Languages, nec  75  0.01%
Assamese    71  0.01%
Arakanese   70  0.01%
Burmese and Related Languages, nec  62  0.01%
Afghan  61  0.01%
Nuer    61  0.01%
Uzbek   60  0.01%
Haka    59  0.01%
Mongolian   59  0.01%
Ndebele 54  0.01%
Hokkien 51  0.01%
Catalan 50  0.01%
Hakka   49  0.01%
Uygur / Uyghur  48  0.01%
Bari    46  0.01%
Flemish 46  0.01%
Krio    44  0.01%
Iranic, nec 43  0.01%
Azeri   40  0.01%
Tok Pisin   40  0.01%
Tongan  40  0.01%
Dhivehi 39  0.01%
Chin Daai   36  0.01%
Kashmiri    36  0.01%
Arabic, Sudanese Creole 35  0.01%
Latvian 35  0.01%
Zulu    35  0.01%
Ilonggo (Hiligaynon)    33  0.00%
Krahn   32  0.00%
Kreole / Creole (African)   32  0.00%
Chin Senthang   30  0.00%
Kurdish, Southern (Feyli)   29  0.00%
Madi    29  0.00%
Oceanian Pidgins and Creoles, nfd   29  0.00%
Acholi  28  0.00%
Luganda / Ganda 28  0.00%
Tswana  28  0.00%
Eastern Kayah   27  0.00%
Ewe 27  0.00%
Irish   27  0.00%
Maltese 26  0.00%
Bassa   24  0.00%
Kikuyu  24  0.00%
Hmong   23  0.00%
Iranic, nfd 23  0.00%
Kazakh  22  0.00%
Mandingo    22  0.00%
Mon 21  0.00%
Belorussian 20  0.00%
Georgian    17  0.00%
Lisu    16  0.00%
Balinese    15  0.00%
Kuku    15  0.00%
Samoan  15  0.00%
Tetum   15  0.00%
Twi (Akan)  15  0.00%
Inadequately dscrbd 14  0.00%
Tai, nfd    14  0.00%
Balochi 13  0.00%
Hausa   13  0.00%
Kissi   13  0.00%
Solomon Islands Pijin   13  0.00%
Kurdish (Sorani)    12  0.00%
Bembe   11  0.00%
Gio 11  0.00%
Moro    11  0.00%
Wu  11  0.00%
Chin Thado  10  0.00%
Fullah  10  0.00%
Grebo   10  0.00%
Javanese    10  0.00%
Kpelle  10  0.00%
Other Southeast Asian Languages, nec    10  0.00%
Xhosa   10  0.00%
Anuak   9   0.00%
Dagbani 9   0.00%
Luo 9   0.00%
Nyanja (Chichewa)   9   0.00%
Serbo-Croatian/Yugoslavian so described 9   0.00%
Teochew 9   0.00%
Chin Mro    8   0.00%
Icelandic   8   0.00%
Loma / Lorma    8   0.00%
Other Eastern Asian Languages, nec  8   0.00%
Turkmen 8   0.00%
Middle Eastern Semitic Languages, nec   7   0.00%
Bislama 6   0.00%
Chin Khumi  6   0.00%
Chin Mun    6   0.00%
Ga  6   0.00%
Gilbertese  6   0.00%
Harari  6   0.00%
Ilokano 6   0.00%
Mende   6   0.00%
Other Southern Asian Languages, nec 6   0.00%
Tai, nec    6   0.00%
Tatar   6   0.00%
Timorese    6   0.00%
Kono (Sierra Leone) 5   0.00%
Limba   5   0.00%
Mano    5   0.00%
Motu    5   0.00%
Nauruan 5   0.00%
Other Southwest and Central Asian Languages, nec    5   0.00%
Pampangan   5   0.00%
Papuan  5   0.00%
Parsun  5   0.00%
Shan    5   0.00%
Vai 5   0.00%
Acehnese    4   0.00%
Afar    4   0.00%
Karen Bwe   4   0.00%
Karen Geko  4   0.00%
Karen Yinbaw    4   0.00%
Letzeburgish    4   0.00%
Oceanian Pidgins and Creoles, nec   4   0.00%
SOUTHWEST AND CENTRAL ASIAN LANGUAGES   4   0.00%
Temne / Themne  4   0.00%
Wolof   4   0.00%
American Languages  3   0.00%
Asante  3   0.00%
Bikol   3   0.00%
Chin Ngawn  3   0.00%
Comorian    3   0.00%
Iban    3   0.00%
Kakwa   3   0.00%
Turkic, nec 3   0.00%
Welsh   3   0.00%
Aromunian (Macedo-Romanian) 2   0.00%
Dravidian, nec  2   0.00%
Faeroese    2   0.00%
German and Related Languages, nfd   2   0.00%
Mon-Khmer, nec  2   0.00%
Rotuman 2   0.00%
SOUTHERN ASIAN LANGUAGES    2   0.00%
SOUTHERN EUROPEAN LANGUAGES 2   0.00%
Susu    2   0.00%
Turkic, nfd 2   0.00%
Auslan  1   0.00%
EASTERN EUROPEAN LANGUAGES  1   0.00%
Finnic, nec 1   0.00%
Frisian 1   0.00%
Fuliiru 1   0.00%
Iberian Romance nec (includes Crioulo   Galician Ladino)    1   0.00%
Kru 1   0.00%
Lango   1   0.00%
Liberian English    1   0.00%
Luba-Kasai  1   0.00%
Niue    1   0.00%
Other Eastern European Languages, nec   1   0.00%
Pacific Austronesian Languages, nec 1   0.00%
Panjsheri   1   0.00%
Pular / Fuuta Jalon 1   0.00%
Sasak   1   0.00%
Shilluk 1   0.00%
Sign Languages, nfd 1   0.00%
Southeast Asian Austronesian Languages  1   0.00%
SOUTHEAST ASIAN LANGUAGES   1   0.00%
Tuvaluan    1   0.00%
Unspec.fmr.Yugoslav 1   0.00%
Yiddish 1   0.00
MIGRATION STREAM        
Family  215134  31.263%
Humanitarian    51958   7.551%
Other   29  0.004%
Skilled 421011  61.182%
Grand Total 688132  
        
GENDER      
Female  369076  53.63%
Male    318936  46.35%
Unknown 4   0.00%
(blank) 116 0.02%
Grand Total 688132  
        
English Proficiency     
Good    7142    1.04%
Nil 51114   7.43%
Not Recorded    338032  49.12%
Poor    163426  23.75%
Very Good   128418  18.66%
Grand Total 688132  
        
Current State       
Australian Capital Territory    12288   1.79%
External Territories    41  0.01%
New South Wales 228293  33.18%
Northern Territory  7450    1.08%
Not Recorded    6042    0.88%
Queensland  89544   13.01%
South Australia 43256   6.29%
Tasmania    5380    0.78%
Victoria    196326  28.53%
Western Australia   99512   14.46%
Grand Total 688132  

Age groups      
00-05   57333   8.33%
06-11   52050   7.56%
12-15   24135   3.51%
16-17   10733   1.56%
18-24   53122   7.72%
25-34   271807  39.50%
35-44   131560  19.12%
45-54   45290   6.58%
55-64   25617   3.72%
65+ 16485   2.40%
Grand Total 688132  
